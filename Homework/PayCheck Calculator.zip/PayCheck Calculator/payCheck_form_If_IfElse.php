<html>
	<body>
		<form action="getPayCheck_If_IfElse.php" method "get">
			What is your pay rate: 
            <input type="text" name="payRate"><br>
            How many hours did you work: 
            <input type="text" name="hoursWorked"><br>
            <input type="submit">
		</form>
	</body>
</html>